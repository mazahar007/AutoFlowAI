import { google } from 'googleapis';

export default async function handler(req, res) {
  const { code } = req.query;

  if (!code) {
    return res.status(400).json({ error: 'Authorization code missing' });
  }

  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    'https://autoflowaii.vercel.app/api/auth/callback'
  );

  try {
    const { tokens } = await oauth2Client.getToken(code);
    return res.status(200).json({
      message: 'YouTube OAuth Authentication Successful!',
      status: 'Connected',
      tokens
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
